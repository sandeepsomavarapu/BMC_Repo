package com.bmc.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@Configuration
@ComponentScan("com.bmc.demo")

public class App {
	public static void main(String[] args) {
//		Resource resource = new ClassPathResource("springconfig.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);
//		Employee emp =(Employee) factory.getBean("emp");

		ApplicationContext context = new AnnotationConfigApplicationContext(App.class);

		Employee emp = (Employee) context.getBean("emp");
		System.out.println(emp);
		System.out.println(emp.getAddress());
	}

	@Bean("emp")
	public Employee getEmployee() {
		Employee emp = new Employee();
		emp.setAddress(getAddress());
		return emp;
	}

	@Bean
	public Address getAddress() {
		return new Address();
	}

}// @Component,@Service,@Repository
//xml,annotation,java config