package com.cap.service;

import java.util.List;

import com.cap.entity.Employee;

public interface EmployeeService {

	public abstract void addEmployee(Employee student);

	public abstract void updateEmployee(Employee student);

	public abstract void removeEmployee(int student);

	public abstract Employee findEmployeeById(int eid);

	public abstract List<Employee> listEmployee();

}
